import Foundation

// if com String
let yes: Bool = true
let no: Bool = false

if no {
    print("Entrou na tela")
}else{
    print("Entrou no Else")
}

let name = "Raul"

if name == "Goms" {
print(name)
} else if name != "Raul"{
    print("Raul")
}else{
    print("cruz")
}

var x = name == "Raul" ? "Raul": "Gomes"

print(x)

// if com Int
let day = 3

if day > 1 {
    print("sim")
} else if day < 2 {
    print("é")
} else {
    print("igual")
}

// if com controladores de fluxo or ou and
if 8 < 9 || 8 > 9 {
 print("if")
}else{
    print("else")
}
