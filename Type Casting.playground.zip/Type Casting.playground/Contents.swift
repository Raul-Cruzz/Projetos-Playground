import Foundation

// Polimorfismo

// Polimorfismo por tempo de compilacao
// Polimorfismo por sobrecarga

func addNums(a: Int, b: Int) -> Int{ // Dois parametros
    return a + b
}

func addNums(a: Int, b: Int, c: Int) -> Int { //sobrescrevendo o metodo
    return a + b + c
}

print(addNums(a: 10, b: 20))
print(addNums(a: 10, b: 20, c: 30))

// Polimorfismo alterando o metodo da super classe atravé do override

//class Animal {
//    func makeNoise() {
//        print("Durr")
//    }
//}

//class Cat: Animal {
//    override func makeNoise() { // Polimorfismo Utilizado para alterar o metodo e o escopo da classe principal, usamos o override para subescrever os metodos das classes e funcoes
//        print("Miauuuu")
//    }
//}
//
//class Dog: Animal {
//    override func makeNoise() {
//        print("Au au au")
//    }
//}
//
//var animal: Animal = Cat()
//animal.makeNoise()

//animal = Dog()
//animal.makeNoise()
//
//animal = Animal()
//animal.makeNoise()


// Type Casting

//let pets = [Dog(), Cat(), Dog(), Dog(), Cat()]
//pets se torna o Array de Animal por conta da referencia de tipos que recebe, se tornando uma colecao de tipos.
// Como todos os tipos herdam de Animal ele entende que o pets é o Array de Animal ou seja uma colecao de tipos.

// Realizand o Loop através do type casting
//
//for pet in pets {
//    if let dog = pet as? Dog {
//        dog.makeNoise()
//    }

// Pega um indice do array para dizer que o dog é um dog se caso nao for da Nil, através do type cating -> as?
// Forcando o tipo de variável ou constante para dizer que um dog é do tipo pet, uma constante.
// Utilizando o makeNoise no qual aprendemos no Polimorfismo

//Realizando o switch no tyoe casting para confirmar se os indices sao verdadeiros.

//switch pet {
//case let dog as Dog:
//    dog.makeNoise()
//case let cat as Cat:
//    cat.makeNoise()
//default:
//    break
//}
//}

// printou os indices na tela de acordo com a sua sequencia dog, cat, dog, dog, cat. Se caso a condicao fosse falsa retornaria um break.


// Extension - extensoes

// As entensoes nos permite incluir uma nova funcionalidade as classes já existentes.
// As extensoes também sao muito úteis se nao tivermos acesso ao código original da classe
// As extensoes nos ajuda a entender a funcionalidade de uma classe ou um protocol - protocolo.
// As extensoes sao muito úteis para que possamos organizar o nossos códigos e também a dar novas funcionalidades para as nossas classes.
// As extensoes podem estar em outro arquivo, nap precisam estar necessariamente no mesmo arquivo da classe.
// Nao conseguimos importar ou alterar uma SDK, mas podemos extender ela através de incluir novas funcionalidades, fazendo isso deixamos o código mais claro para o uso.

class Person {
    var hair: String
    var age: Double
    var size: Double    // atributos
    var name: String
    var lastName: String
    
    init(hair: String, age: Double, size: Double, name: String, lastName: String) {  //inicializacao da classe
    self.hair = hair    // inicializando os atributos da classe.
    self.age  = age // O segundo hair vem de fora da classe, quem chamar a classe vai chamar o segundo hair
    self.size = size
    self.name = name
    self.lastName = lastName
        
    }

}

// Adicionando uma nova funcionalidade na classe

extension Person {
    func getfullName() ->  String { // Metodo
        return "\(name) \(lastName)"
    }
}

// instanciando a variavel Person

//var person = Person(hair: "longo", age: 28, size: 1.77, name: "Raul", lastName: "Gomes") // Propriedade
//
//print(person.getfullName())

// Criando uma nova funcionalidade

// Um código coeso ou ajustado ajuda o último ou o código atual a concluir uma tarefa.
// A String faz parte do próprio swift, nao tem como alterar ela ou as funcionalidades da própria String ou Struct também, mas podemos incluir novas funcionalidades a elas.
// A extension nos da o poder de mudar a funcionalidade dos tipos, nesse cao o tipo String, mudando o mesmo através de uma nova funcionalidade que estamos atribuindo a ela.

extension String {
    
    func replace(target: String, withString: String) -> String { // Criando um novo metodo
        return self.replacingOccurrences(of: target, with: withString)
    }
    
    var length: Int { // Criando uma nova propriedade para contar a quantidade de caracteres da nossa string
        get {
            return self.count
        }
    }
}

let newString = "the old String".replace(target: "old", withString: "new")
print(newString)
print(newString.length)


// Struct vs Classes

// Struct nao tem referencia e sim valor do tipo cópia.
// Classe nao tem valor e sim referencia que vem direto da memória.


// Deinit - Destruir classe

class Animal {
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("\(name) is remove")
    }
}

var dog: Animal? = Animal(name: "dog")
print(dog!.name)
dog = nil
