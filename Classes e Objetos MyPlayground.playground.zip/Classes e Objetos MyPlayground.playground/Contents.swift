import Foundation

//Classe

class Person {
    var hair: String
    var age: Double
    var size: Double    // atributos
    var name: String
    var lastName: String
    
    var fullname: String {
        "\(name) \(lastName)"
    }
    
    init(hair: String, age: Double, size: Double, name: String, lastName: String) {  //inicializacao da classe
    self.hair = hair    // inicializando os atributos da classe.
    self.age  = age // O segundo hair vem de fora da classe, quem chamar a classe vai chamar o segundo hair
    self.size = size
    self.name = name
    self.lastName = lastName
        
    }

}

//Objeto - instancia

//var person01 = Person(hair: "longo", age: 28, size: 1.77, name: "Gomes", lastName: "Raul")
//var person02 = Person(hair: "curto", age: 20, size: 1.60, name: "Gomes", lastName: "Karina")
//
//print(person01.fullname) // retirando o objeto e ficando só com a classe.
//print(person02.fullname)


// Utilizando a herenca para espelhar os valores em um nova classe.


//class Student {
//    var age: Double
//    var size: Double    // atributos
//    var name: String
//    var lastName: String
//    var grade: Double
//    var course: String
//
//    init(age: Double, size: Double, name:String, lastName: String, grade:Double, course: String) {
//        self.age = age
//        self.size = size
//        self.name = name
//        self.lastName = lastName
//        self.grade = grade
//        self.course = course
//
//    }
//
//}

// Utilizando a herenca com uma nova classe mas com novos atributos
// Para utilizar ou inicializar a herenca, utilizamos o Super.init, o super.init é utiizado quando ususamos uma subclasse, uma classe que herda os atributos de outra classe no casso a clase mae

class Student: Person {  // Heranca única - quando uma classe do swift só pode ser herdada por outra classe
    var grade: Double // Atributos
    var course: String
    
    init(grade:Double, course: String, hair: String, age: Double, size: Double, name: String, lastName: String) {
        self.grade = grade  //Argumentos e Propriedades
        self.course = course
        
        super.init(hair: hair, age: age, size: size, name: name, lastName: lastName)
        // Super.init - nos trás os atributos da super classe ou clase base
    }
    
    convenience init(grade: Double, course: String) { // Criando o metodo e retornando o valor da nota
        self.init(grade: grade, course: course, hair: "", age: 0, size: 0, name: "Carlos", lastName: "Carmo")
    } // Sempre chamar o convenience no init da classe
    
    func getGrade() -> Double {  // Criando o metodo e retornando o valor da nota***
        return grade // funcao sem o self porque o getgrade já entende que a Grade é um atributo do tipo Double
    }
}
//instanciar a classe student - Objeto
var student01 = Student(grade: 8.9, course: "iOS", hair: "longo", age: 28, size: 1.89, name: "Carlos", lastName: "Carmo")

var student02 = Student.init(grade:10.0, course: "swift")

student01.fullname    // sub classe
student02.fullname    // classe
student01.getGrade() // init da sub classe
student02.getGrade() // super.init - init da classe


// Encapsulamento

//private nao permite que o código seja alterado fora da extensao ou da subclasse
//fileprivate só permite que as alteracoes sejam realizadas no mesmo arquivo, se criar um novo arquivo e tentar usar o código ou o atributo do arquivo anterior ele nao permite, gerando um bloqueio. Proteje os atributos dentro do arquivo sem que possam ser vistos de um arquivo externo. Ele protege dentro da extenshion, e subclasse.
//Public deixa o módulo visível ou a classe na qual foi escolhida.
//Open é igual ao Public só que com um adicional que é a permissao de conceder a substituicao do código em outro módulo.
//Private e Public sao os mais utilizados.


// Polimorfismo

// Polimorfismo por tempo de compilacao
// Polimorfismo por sobrecarga

func addNums(a: Int, b: Int) -> Int{ // Dois parametros
    return a + b
}

func addNums(a: Int, b: Int, c: Int) -> Int { //sobrescrevendo o metodo
    return a + b + c
}

print(addNums(a: 10, b: 20))
print(addNums(a: 10, b: 20, c: 30))

// Polimorfismo alterando o metodo da super classe atravé do override

class Animal {
    func makeNoise() {
        print("Durr")
    }
}

class Cat: Animal {
    override func makeNoise() { // Polimorfismo Utilizado para alterar o metodo e o escopo da classe principal, usamos o override para subescrever os metodos das classes e funcoes
        print("Miauuuu")
    }
}

class Dog: Animal {
    override func makeNoise() {
        print("Au au au")
    }
}

var animal: Animal = Cat()
animal.makeNoise()

animal = Dog()
animal.makeNoise()

animal = Animal()
animal.makeNoise()
