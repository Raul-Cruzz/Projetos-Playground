import UIKit
import Foundation

//ja nos tras a configuracao pronta, uma api do swift que nos permite configuracoes limitadas
let sharedSession = URLSession.shared
sharedSession.configuration.allowsCellularAccess
sharedSession.configuration.allowsCellularAccess = false
sharedSession.configuration.allowsCellularAccess
// o sharedSession nao nos permite realizar alteracoes
// singou é um padrao de projeto e nos garante e permite que a classe tenha apenas uma instancia, enquanto a gente prova outros pontos de acesso global para aquela instancia
// A instancia foi criada como true e nao tem como alterar

let myDefaultConfiguration = URLSessionConfiguration.default // esse salva os caches, credenciais
let apConfig = URLSessionConfiguration.ephemeral // nao salva nada
let backConfig = URLSessionConfiguration.background(withIdentifier: "EBAC") // esse também salva da mesma forma

myDefaultConfiguration.allowsCellularAccess = false
myDefaultConfiguration.allowsCellularAccess

// Na URLSessionConfiguraton conseguimos alterar e personalizar a nossa instancia

// metodos que para dados caros andam juntos
myDefaultConfiguration.allowsExpensiveNetworkAccess = true
myDefaultConfiguration.allowsConstrainedNetworkAccess = true // vetor true

// criando a nossa sessao
let myDefaultSession =  URLSession(configuration: myDefaultConfiguration)
myDefaultSession.configuration.allowsConstrainedNetworkAccess

let defaultSession = URLSession(configuration: .default) // é um default true
defaultSession.configuration.allowsCellularAccess

