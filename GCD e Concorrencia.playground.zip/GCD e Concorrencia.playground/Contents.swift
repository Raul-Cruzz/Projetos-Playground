import Foundation
import UIKit

 // nesse caso dependerá do framework escolher qual será o primeiro a ser printado, devido nao ter sequencia e sim o que levar menos tempo será printado.

let queue = DispatchQueue.global(qos: .userInteractive) // interface, background é outro

queue.async {
    print("1")
}

print("2")

//com essa ocao de esperar 5 segundos a forma assincrona entra em acao nos trazendo o segundo print debaixo para cima, printando o que leva menos tempo.

queue.asyncAfter(deadline: .now() + 0.5) {
    print("1")
}

print("2")

//Por ser um comando simples de executar, ele nao viu problema e rodou todos na sequencia, se fosse algo mais dificil o mais rapido seria executado.

let queue1 = DispatchQueue(label: "queue1")
let queue2 = DispatchQueue(label: "queue2")
let queue3 = DispatchQueue(label: "queue3")

queue1.async {
    for index in 1...10 {
        print(index)
    }
}

queue2.async {
    print(2)
}

queue3.async {
    print(3)
}

print("end")
