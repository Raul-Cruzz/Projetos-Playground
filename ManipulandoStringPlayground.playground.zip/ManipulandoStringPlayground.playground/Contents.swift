import Foundation

// Loop, utilizado para ler e extrair a quantidade de caracteres da String //

var greeting = "Hello"

for char in greeting {
    print(char)
}

// outra forma de utilizar o loop para saber a quantidade de caracteres //

  var greeting = "Hello"

  print(greeting.count)

// forma de identificar um único caraceter, no caso o primeiro //

 var greeting = "Hello"

 let index = greeting.startIndex

 let char = greeting[index]

 print(char)

// forma de obter o primeiro e último caracter //

 var Greeting = "Hello"

 let firstIndex = greeting.startIndex

 let lastIndex = greeting.index(before: greeting.endIndex)

 let firstChar = greeting[firstIndex] // forma abreviada

 let lastChar = greeting[lastIndex]

 print(firstChar)
 print(lastChar)

// deslocando o index e filtrando o tipo de caracter da sting de forma selecionada //

 var Greeting = "Hello"

 let firstIndex = greeting.startIndex

 let lastIndex = greeting.index(greeting.startIndex, offsetBy: 4)

 let firstChar = greeting[firstIndex] // forma abreviada
 let lastChar = greeting[lastIndex]

 print(firstChar)
 print(lastChar)

// Sub String - extrair uma parte da string do seu próprio valor //

 let name = "Raul Gomes"

 let spaceIndex = name.firstIndex(of: " ")!
 let firstname = name[name.index(after: spaceIndex)...]
 let firstname = name[name.startIndex..<spaceIndex]
 let firstname = name[..<spaceIndex] - Segunda forma
// utilizando a Sub string para extrair o primeiro e segundo nome antes de depois do espaco //
// indice de String //

 let withoutInterpolation = "sem interpolacao"

 let rowString = #"teste com row string \#(withoutInterpolation). Esse é um dos usos!"#

 print(rowString)

// Exemplo Opicionais //

// var greeting: String = "Hello, playground"
// greeting = nil -> String nao pode receber valores nulos //

// var color: UIcolor = UIcolor.red //
// color = UIcolor.red -> atribuindo valor //

// Utilizando a opcao ? -> para anular um valor //

 var Greeting: String
 var age: Int //
 var result: Int? //-> opcao tornando o valor nulo

 greeting = "Hello, playground"
 age = 20

 result = Int(age) //-> conversao de tipo que nao é possível ser realizada e por conta disso esse valor vai se tonar nulo através da opcao ? //

 if let result = result {
 result * 2
} else {        // ----> operacao lógico para utilizar o Unwrapping
   "Sem valor"
 }

class ViewController: UIViewController {
var label: UILabel?
}

var optionalString: String? = nil
var haveResult = optionalString ?? "Hey" // ----> operacao Optional e Coalescing, trabalha em extrair e converter as variáveis de forma segura como o Unwrapping, o valor Hello mas se acaso nao conseguir ele manda o valor Hey na haveResult e imprimi na tela, a ? opcao permite esse loop de valores

if let unwrapped = optionalString {
    haveResult = unwrapped
} else {
    haveResult = "Hey"
} // ----> forma lógica de utilizar as ferramentas Unwrapping, Optional e Coalescing e poder desembrulhar determinadas tarefas utilizando o operador optional que nos permite utilizar o valor verdadeiro ou nulo.
// optionalString! ----> Forma nao segura!

// Statement Guard //

func getPerson(person: String?) {
    guard let name = person  else {
        print("No person!")
        return
    }
    
    print("Hello, \(name)")
}

getPerson(person: "Raul")

// forma de declarar uma imagem pelo playground //

 var imageView = UIImageView()
 imageView.image = UIImage(named: "dowload(1)")

 let imageSize = imageView.image?.size

 print(imageSize)

