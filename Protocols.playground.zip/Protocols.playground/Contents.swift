import Foundation

//Protocols

// Forma de criar um protocol

// Acrescentando o enum na nosso protocol para direcionar

enum Direction {
    case left
    case right
}

protocol Vehicle {    // protocol, a ideia de um veiculo que pode acelerar e parar!!!
    func accelerate() // -> metodos
    func stop()
    func turn(_ direction: Direction)
    var name: String { get set } // -> Propriedade com leitura e gravacao
    init(initialVehicle: String) // -> inicializando o protocol
}

class Bike: Vehicle {
    
    var peddling = false
    var brakesApplied = false
    var name: String
    var direction: Direction
    
    required init(initialVehicle: String) {
        name = initialVehicle
        direction = .right
    }
    
    func accelerate() {
        print("acelerar")
        peddling = true
        brakesApplied = true   // essa forma utilizamos nas structs e nas classes.
    }
    
    func stop() {
        print("parar")
        brakesApplied = false
        peddling = false
    }
    
    func turn(_ direction: Direction) {
        self.direction = direction
        print(direction)
    }
}

var bike = Bike (initialVehicle: "Caloi") // -> instaciando a classe
bike.accelerate()
bike.turn(.left)
print(bike.peddling)
