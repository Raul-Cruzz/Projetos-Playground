// Closures -> Método //

// Closure é uma funcao anonima

// trabalhando com funcoes anonimas

var multiplyAnomynous = { (a: Int, b: Int) -> Int in
    return a * b
    
}

//forma de declarar sem o return
multiplyAnomynous = { (a: Int, b: Int) -> Int in a * b }

// forma de declarar sem o tipo Int
multiplyAnomynous = { (a, b) in a * b }

//Omitindo parametro e utilizando o Index $0 e $1 do tipo Int
multiplyAnomynous = { $0 * $1 }

// inserindo os valores nos parametros anonimos e realizando a multiplicacao
let result = multiplyAnomynous(2, 5)


// A Closure nao possui números externos para os parametros, precisamos chama-los logo em seguida, diferente da funcao na qual possui os números externos


// Essa funcao nos trás os elementos ou argumentos de maiores caracteres primeiro, utilizando o sorted de ordenar a constante e os index $0 e $1 junto com o .count para contar os index ou elemestos da nossa funcao

var players: [String] = ["Raul", "Gomes", "Cruz", "Rafael"]

let stringlong = players.sorted {
    $0.count > $1.count
}

print(stringlong)

// Outra forma de extrair os argumentos

players.forEach{
 print("\($0)")
}

// Outra forma de usar o Closure, desta vez usando o map para fazer o uppercased e nos retornar um novo Array com as letras dos argumentos de forma maiúsculas

let mapName = players.map { $0.uppercased()}
print(mapName)

// Também podemos utilizar o filter para filtrar o nosso Array e nos trazer elementos específicos de determinados caracteres

let filterName = players.filter { $0.count > 4}
print(filterName)

// Todas essas funcoes usam Clouseres para realizar essas operacoes

// Utilizando o reduce para somar todos os caracteres do nosso Array

let sum = players.reduce (0, {$0 + $1.count})
print(sum)

//Só para reforçar o entendimento, o exercício 3 retorna um array de strings com os nomes ordenados pela idade.//******


//Struct - Estrumento - Parte 1 //


//sleep - chamando o struct
// Struct, o nome da struct e suas propriedades e parametros
struct User {
    var firstName:  String
    let lastName: String        // Propriedade Armazenada - ficam armazenadas e alocadas na memória.
    var email: String
    var isActive: Bool
    var age: Int
    
    var fulName: String {      // StorePoped - Sao Propriedades Computacionais e nos repassam os valores que nao ficam alocados na memória.
        return "\(firstName) \(lastName) "
    }
    
    // funcao dentro da struct - chamando os parametros
    func printfulname() {
        print ("\(firstName) \(lastName)")
    }
    
    mutating func activeUser() {
        isActive = true
    }
}

var user = User(firstName: "Raul", lastName: "Gomes", email: "raulgomes793@gmail.com", isActive: false, age: 27)
print(user.isActive) // Teste antes de printar a funcao

//print(user.firstName)
//print(user.fulName)
user.printfulname() // printando a funcao

//Alterando a propriedade e-mail que é uma variavel!

user.email = "meu@email.com"
print(user.email)

user.activeUser()
print(user.isActive) // Teste depois de printar a funcao


// Struct - Parte 2 //


// Para alterar a propriedade da struct na funcao, precisamos utilizar o mutanting para mutar a funcao e ai sim alter ou ativar a propriedade.
// Nessa caso vamos ativar a propriedade através do mutating, dentro da struct.

//mutating func activeUser() {
//    isActive = true
//}

//user.activeUser()
//print(user.isActive) // Teste depois de printar a funcao


// Tipo de valores sao atribuidos de cópias, exemplo:

var a = 5
var b = a // = valor de atribuicao, atribuindo o valor de a para b. // valor de igualdade == para comparar valores

print(a)
print(b)

a = 10

print(a)
print(b) // b continuou valendo 5 porque a struct é por tipo valor ou seja ela copia os valores, por isso nao teve alteracoes.


// Enum - Parte 1 //

// Enum é uma lista de valores relacionados que define um tipo comum e permite que voce trabalhe com valores de uma maneira mais segura.
// Enum é uma forma segura de voce poder fazer uma comparacao.

// Membros possiveis do enum, exemplo de um jogo, sempre inicia com a letra minúscula assim como na struct e na classe

//enum MoveDirection: Int {
//    case forward = 1 // -> atribuicao implicita de valores
//    case back      // forma tradicional
//    case left
//    case right
//}

//enum MoveDirection {
//    case forward, back, left, right      // forma simples
//}

//var move = MoveDirection.left
//print(move.rawValue) // rawValue - utilizado para pegar o valor bruto do tipo
//
//switch move {
//case .forward:
//    print("Mover para frente")
//case .back:
//    print("Mover para trás")
//case .left:
//    print("Mover para esquerda")
//case .right:
//    print("Mover para direita")
//}
// // Realizando a comparacao atravé da funcao
//
//func doMove(_ movement: MoveDirection) {
//    switch move {
//    case .forward:
//        print("Mover para frente")
//    case .back:
//        print("Mover para trás")
//    case .left:
//        print("Mover para esquerda")
//    case .right:
//        print("Mover para direita")
//}
//
//}
//
// primeira forma de printar
//doMove(move)
// sedunda forma
//doMove(MoveDirection.left)
// terceira forma, utilizando a atribuicao esquerdaß
//doMove(.left)

// Declarar o tipo no caso o MoveDirection que possui o membro Left, sem declarar o tipo da erro


// Enums com valores //

//enum MoveDirection: Int {
//    case forward = 1 // -> atribuicao implicita de valores
//    case back      // forma tradicional
//    case left
//    case right
//}

//enum MoveDirection {
//    case forward, back, left, right      // forma simples
//}

//var move = MoveDirection.left
//print(move.rawValue) // rawValue - utilizado para pegar o valor bruto do tipo
//


// Enum com valores associados - associeted values//

enum Medir {
    case peso(Double)  // Peso -- weight
    case idade(Int)       // Valor inteiro -- age
    case tamanho(width: Double, height: Double) // Tamanho com Dois parametros cmprimento e altura  -- size
}

//var medir = Medir.idade(28) // forma de ter o valor associado chamando o enum, chama o membro e passa o valor do tipo double ou int para ele.
//var peso = Medir.peso(82)
//var tamanho = Medir.tamanho(width: 19, height: 20)

//switch medir {
//    case .idade(let age): // podemos utilizar outra palavra afim de associar o nosso valor inteiro
//        print("Minha idade é: \(age)")
//    case .peso(let weight):
//        print("Meu peso é: \(weight)")
//    case .tamanho(let height, let width):
//        print("Meu tamanho \(height), Meu comprimento \(width)") // forma de declarar sem o size -- Dois argumentos
//}

//switch peso {
//    case .idade(let age): // podemos utilizar outra palavra afim de associar o nosso valor inteiro
//        print("Minha idade é: \(age)")
//    case .peso(let weight):
//        print("Meu peso é: \(weight)")
//    case .tamanho(let height, let width):
//        print("Meu tamanho \(height), Meu comprimento \(width)") // forma de declarar sem o size -- Dois argumentos
//}
//
//switch tamanho {
//    case .idade(let age): // podemos utilizar outra palavra afim de associar o nosso valor inteiro
//        print("Minha idade é: \(age)")
//    case .peso(let weight):
//        print("Meu peso é: \(weight)")
//    case .tamanho(let height, let width):
//        print("Meu tamanho \(height), Meu comprimento \(width)") // forma de declarar sem o size -- Dois argumentos
//}

// Trabalhando com a funcao afim de trazer todos os dados como idade, peso e tamanho

let firstName = "Raul gomes da cruz"
print(firstName)


var medir = Medir.idade(28)
var medir2 = Medir.peso(82.0)
var medir3 = Medir.tamanho(width: 177.0, height: 20)

func printEnum (_ medir: Medir) {
    switch medir {
        case .idade(let age): // podemos utilizar outra palavra afim de associar o nosso valor inteiro
            print("Minha idade é: \(age)")
        case .peso(let weight):
            print("Meu peso é: \(weight)")
        case .tamanho(let height, let width):
            print("Meu tamanho \(height), Meu comprimento \(width)") // forma de declarar sem o size -- Dois argumentos
    }
}

printEnum(medir)
printEnum(medir2)
printEnum(medir3)

