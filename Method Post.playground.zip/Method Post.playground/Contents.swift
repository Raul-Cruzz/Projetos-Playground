import UIKit

//URLrequest é feito para fazer o carregamento ou o load em si da URL, parecido com o URLSession, URLrequest é de fato enviar um carregamento.
//criando o servidor atraves do heroku para receber post nesse servidor. Json recebendo os valores de usuário.

let urlencoded = "user=Raul&password=1231231 " // enviando a requisicao de post e convertendo para dados
let url = URL(string: "http://127.0.0.1:8080/login")!
var request = URLRequest(url: url) // realizando a requisicao de URL

request.httpMethod = "Post" // metodo
request.httpBody = urlencoded.data(using: .utf8) // corpo de requisicao
//utilizando o utf8 para converter para banco de dados.

let session = URLSession(configuration: .default)

let task = session.dataTask(with: request) { (data, response, error) in
    if let data = data {
        if let postResponse = String(data: data, encoding: .utf8) {
            print(postResponse)
        }
    }
}

task.resume()
