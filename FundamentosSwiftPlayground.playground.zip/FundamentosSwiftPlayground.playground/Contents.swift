import Foundation

var greeting = "Hello, playground"

func printGreetig() {
    print(greeting)
}

printGreetig()

// Anotacoes //
func printGreent(_ say: String, _ name: String) -> String {
    return say + " - " + name
}

var test: String = printGreent(greeting, "Raul")
//
//func printTest(_ text: inout String) -> String {
//    print(text)
//    text = "TESTE"
//    return text
//}
//
//print(printTest(&test))
//
//print(test)

/*func greet (person: String, from hometown: String) {
    print("Hello \(person)! from \(hometown).")
}*/

func greet(_ person: String, from hometown: String) {
    print("1 Hello \(person)! from \(hometown).")
}

func greet(person: String, from hometown: String) {
    print("2 Hello \(person)! from \(hometown).")
}

func greet(_ person: String, _ hometown: String) {
    print("3 Hello \(person)! from \(hometown).")
}

greet("Raul", "Sao Paulo")


//func greet(_ person: String, from hometown: String) -> String{
//    return "1 Hello \(person)! from \(hometown)."
//}
//
//func greet(person: String, from hometown: String) -> Int{
//    return 2
//}
//
//var test: String = greet("Raul", from: "Sao Paulo")




